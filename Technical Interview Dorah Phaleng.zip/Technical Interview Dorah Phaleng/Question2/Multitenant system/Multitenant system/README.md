# Multitenant application

A multitenant app built with django. Uses Isolated db for each tenant with a shared app server.







