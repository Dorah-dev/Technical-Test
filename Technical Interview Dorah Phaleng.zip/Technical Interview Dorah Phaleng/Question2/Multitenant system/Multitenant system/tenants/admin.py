from django.contrib import admin
from .models import Tenant
# Register your models here.
admin.site.register(Tenant)