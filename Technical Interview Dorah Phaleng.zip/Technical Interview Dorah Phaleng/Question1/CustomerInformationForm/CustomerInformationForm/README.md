

# customer information in Python


a beautiful GUI based customer information window with database using python tkinter module.

Requirements: 
        
        Python
        PyCharm
        Xampp



<b>Description: </b>

It is a basic customer information form that can be used in all types of management. I used tkinter module and tried to use all its 
function.I used tkinter, pillow, pymysql module.

<b>Features</b>

    - label added
    
    - Error ( All fields are required) added -> if any field is empty it will show message
    
    - Error ( Password didn't match) added -> if password and confirm password don't match
    
    - Error ( Terms and Conditions didn't select) -> if checkbox is empty
    
    - Successful registration added
    
    - Database added -> to store all records
    
    - Sign in added -> which will go to the Login Page 
    

In Private Repository, I added Login Page which pictures are down below.

<b>Features</b>
    
    - Animated pictures added
    
    - Error ( All fields are required) added -> if any field is empty it will show message
    
    - Error ( Username and Password didn't match) -> if any of them is wrong
    
    - Forget Password option added 
    
    - Error ( All fleids are required) added in forget password -> security test
    
    - Error (Wrong Info) added in forget password -> security query doesn't match
    
    - Reset Button added -> if successfully operation occurs
    
    - Login success added -> A message box will pop out 




